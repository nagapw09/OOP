﻿// ex1.cpp
/* Для индивидуального варианта описать класс, описав конструкторы, деструктор, заданные поля и метод.
10 вариант
Вещественное число - первый катет прямоугольного треугольника
Вещественное число - второй катет прямоугольного треугольника
Вычислить длину гипотенузы прямоугольного треугольника */

#include <iostream>
#include <cmath>
using namespace std;

class Triangle
{
	double a, b, hypotenuse;
public:
	Triangle() { a = 0; b = 0; hypotenuse = 0; }

	Triangle(double a, double b) { this->a = a; this->b = b; }

	double Get_a() { return a; }
	double Get_b() { return b; }

	double Get_hypotenuse() { return (sqrt(pow(a, 2) + pow(b, 2))); }

	void Set_a(double a) { this->a = a; }
	void Set_b(double b) { this->b = b; }

	~Triangle() {}
};

int main()
{
	Triangle ABC(15.5, 25.8);
	cout << "Hypotenuse of Triangle = " << ABC.Get_hypotenuse() << endl;

	ABC.Set_a(5.3);
	ABC.Set_b(10.4);
	cout << "Hypotenuse of Triangle = " << ABC.Get_hypotenuse() << endl;

	system("pause");
	return 0;
}
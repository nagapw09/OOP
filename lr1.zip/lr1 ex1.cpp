﻿/* lr1 ex1.cpp Создать класс: СТРАНА Название Население Площадь
2. Описать в классе конструктор без параметров, в котором сообщается о создании объекта.
3. Описать деструктор с сообщением о его работе.
4. Описать в классе конструктор с параметрами, которые задают начальные значения атрибутов класса.
5. Описать в классе конструктор копирования с выводом сообщения на экран.
6. Указать в классе уровни доступа и описать функции-члены класса для получения доступа к атрибутам класса.
7. Реализовать класс и продемонстрировать работу всех конструкторов и методов. */

#include <iostream>
#include <string>
using namespace std;

class Country
{
private:
	string name;
	double population;
	double area;

public:
	Country() { cout << "Конструктор без параметров\n"; }

	Country(string name, double population, double area)
	{
		cout << "Конструктор с параметрами\n";
		this->name = name;
		this->population = population;
		this->area = area;
	}

	string Get_name() // get для атрибутов класса
	{
		return name;
	}

	double Get_population()
	{
		return population;
	}

	double Get_area()
	{
		return area;
	}

	void Set_name(string name) // set для атрибутов класса
	{
		this->name = name;
	}

	void Set_population(double population)
	{
		this->population = population;
	}

	void Set_area(double area)
	{
		this->area = area;
	}

	Country(const Country& firstreal)
	{
		cout << "Конструктор копирования\n";
		this->name = firstreal.name;
		this->population = firstreal.population;
		this->area = firstreal.area;
	};

	void Print()
	{
		cout << "Страна " << name << "\nНаселение = " << population << " миллионов человек\n" << "Площадь = " << area << " км/2\n";
	}

	~Country()
	{
		cout << "Вызвался деструктор\n";
	}
};

int main()
{
	setlocale(LC_ALL, "Ru");

	Country firstname("Украина", 41.98, 603.628);
	firstname.Print();

	Country secondname(firstname);
	secondname.Print();

	system("pause");
	return 0;
}
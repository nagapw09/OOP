﻿// lr1 ex2.cpp
/* Изменить класс из задания 1
1. Предусмотреть динамическое выделение памяти для выбранного атрибута класса.
2. Описать деструктор для освобождения памяти.
3. В соответствии с этим изменить все другие элементы класса для корректной работы.
4. Реализовать класс и продемонстрировать работу всех конструкторов и методов. */

#include <iostream>
#include <string>
using namespace std;

class Country
{
private:
	string* name = new string;
	double* population = new double;
	double* area = new double;
public:
	//Country() { cout << "Конструктор без параметров\n"; }

	Country(string name, double population, double area)
	{
		cout << "Конструктор с параметрами\n";
		*(this->name) = name;
		*(this->population) = population;
		*(this->area) = area;
	}

	string Get_name() // get для атрибутов класса
	{
		return *name;
	}

	double Get_population()
	{
		return *population;
	}

	double Get_area()
	{
		return *area;
	}

	void Set_name(string name) // set для атрибутов класса
	{
		*(this->name) = name;
	}

	void Set_population(double population)
	{
		*(this->population) = population;
	}

	void Set_area(double area)
	{
		*(this->area) = area;
	}

	Country(const Country& firstreal)
	{
		cout << "Конструктор копирования\n";
		*(this->name) = *(firstreal.name);
		*(this->population) = *(firstreal.population);
		*(this->area) = *(firstreal.area);
	};

	void Print()
	{
		cout << "Страна " << *name << "\nНаселение = " << *population << " миллионов человек\n" << "Площадь = " << *area << " км/2\n";
	}

	~Country()
	{
		cout << "Вызвался деструктор\n";
		delete name;
		delete population;
		delete area;
	}
};

int main()
{
	setlocale(LC_ALL, "Ru");

	Country firstname("Украина", 41.98, 603.628);
	firstname.Print();
	
	Country secondname(firstname);
	secondname.Print();

	system("pause");
	return 0;
}
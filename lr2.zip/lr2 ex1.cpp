﻿// lr2 ex1.cpp
/* Для класса индивидуального задания Лр1 описать публичный статический член класса для подсчета числа созданных объектов.
Проверить работоспособность кода. Результат описать в комментариях. */

#include <iostream>
#include <string>
using namespace std;

class Country
{
private:
	string name;
	double population;
	int area;
public:
	static int sum;
	static int getSum() { return sum; }

	Country() { population = 0; area = 0; }

	Country(string _name, double _population, int _area)
	{
		name = _name;
		population = _population;
		area = _area;
		sum++;
	}

	void Print()
	{
		cout << "Страна " << name << "\nНаселение = " << population << " миллионов человек\n" << "Площадь = " << area << " км/2\n\n";
	}

	~Country() { sum--;}
};

int Country::sum = 0;

int main()
{
	setlocale(LC_ALL, "Ru");

	Country firstname("Украина", 41.98, 603628);
	firstname.Print();

	Country secondname("Россия", 144.5, 17100000);
	secondname.Print();

	Country thirdname("Южная Корея", 51.64, 100210);
	thirdname.Print();

	Country fourthname("Япония", 126.5, 377915);
	fourthname.Print();

	Country fifthname("Англия", 55.98, 130395);
	fifthname.Print();

	cout << Country::getSum() << " объектов в классе\n";

	system("pause");
	return 0;
	// Результат sum = 5
}
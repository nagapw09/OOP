﻿// lr3 ex1.cpp
/* Определить иерархию классов (в соответствии с индивидуальным вариантом задания),
и логически обоснованный набор атрибутов и функций классов.
Квитанция, Накладная, Документ, Чек. */

#include <iostream>
#include <string>
using namespace std;

class Document
{
protected:
	string definition;
	string variety;
public:
	Document() { definition = ""; variety = ""; }

	Document(string _definition, string _variety)
	{
		definition = _definition;
		variety = _variety;
	}

	string Get_Definition()
	{
		return definition;
	}

	string Get_Variety()
	{
		return variety;
	}

	void Set_Definition(string _definition)
	{
		definition = _definition;
	}

	void Set_(string _variety)
	{
		variety = _variety;
	}

	void Print()
	{
		cout << "Определение:\n" << definition << endl << "Классификация:\n" << variety << endl << endl;
	}

	~Document() {}
};

// Квитанция
class Receipt : public Document
{
public:
	Receipt()
	{
		definition = ""; variety = "";
	}

	Receipt(string _definition, string _variety)
	{
		definition = _definition;
		variety = _variety;
	}

	~Receipt() {}
};

// Накладная
class Invoice : public Document
{
public:
	Invoice()
	{
		definition = ""; variety = "";
	}

	Invoice(string _definition, string _variety)
	{
		definition = _definition;
		variety = _variety;
	}

	~Invoice() {}
};

// Чек
class Check : public Document
{
public:
	Check()
	{
		definition = ""; variety = "";
	}

	Check(string _definition, string _variety)
	{
		definition = _definition;
		variety = _variety;
	}

	~Check() {}
};

int main()
{
	setlocale(LC_ALL, "Ru");

	Document Document1("Это зафиксированная на материальном носителе информация в виде текста, звукозаписи или изображения с реквизитами, позволяющими её идентифицировать.", "Электронный, правоустанавливающий, товарораспорядительный документы.");
	Receipt Receipt1("Расписка в официальном виде установленной формы в приёме денежных средств, каких-либо документов, ценностей.", "Багажная, грузовая, доковая квитанции, квитанция о получении денег.");
	Invoice Invoice1("Документ, используемый при передаче товарно-материальных ценностей от одного лица другому.", "Товарная, транспортная накладные.");
	Check Check1("Ценная бумага, содержащая ничем не обусловленное распоряжение чекодателя банку произвести платёж указанной в нём суммы чекодержателю.", "Банковский, денежный, товарный, дорожный, кассовый, именной, предъявительный, альтернативный, фиктивный чеки.");

	cout << "Документ\n"; Document1.Print();
	cout << "Квитанция\n"; Receipt1.Print();
	cout << "Накладная\n"; Invoice1.Print();
	cout << "Чек\n"; Check1.Print();

	system("pause");
	return 0;
}
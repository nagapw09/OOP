﻿// lr3 ex3.cpp
/* Проанализировать возможности для описании иерархии классов фигур из Лр2
с использованием абстрактных классов, виртуальных функций и замещения методов (*возможно агрегации). */

#include <iostream>
#include <cmath>
using namespace std;

class Point
{
public:
	double x, y;

	Point() { x = 0; y = 0; }

	Point(double _x, double _y)
	{
		x = _x;
		y = _y;
	}

	void Print()
	{
		cout << "x = " << x << "\ty = " << y << endl;
	}

	~Point() {}
};

class Line : public Point
{
	double length;
public:
	Line() { length = 0; }

	Line(Point& objectOne, Point& objectTwo)
	{
		length = sqrt(pow(objectTwo.x - objectOne.x, 2) + pow(objectTwo.y - objectOne.y, 2));
	}

	double Get_Length() { return length; }

	void Print()
	{
		cout << "Length Line = " << Get_Length() << " cm\n";
	}

	~Line() {}
};

class Circle : public Point
{
	double r, S, length;
public:
	Circle() { r = 0; S = 0; length = 0; }

	Circle(double _x, double _y, double _r)
	{
		x = _x;
		y = _y;
		r = _r;
		S = 3.14 * r * r;
		length = 2 * 3.14 * r;
	}

	double Get_S() { return S; }
	double Get_Length() { return length; }

	void Print()
	{
		cout << "Area = " << Get_S() << " cm squared\n";
		cout << "Length = " << Get_Length() << " cm\n\n";
	}

	~Circle() {}
};

class Figure
{
protected:
	double x, y, P, S, length, h, p, diagonal;
public:
	Figure() { x = 0; y = 0; P = 0; S = 0; length = 0; h = 0; p = 0; diagonal = 0; }

	double Get_P() { return P; }
	double Get_S() { return S; }
	double Get_diagonal() { return diagonal; }

	virtual void Print() = 0;

	~Figure() {};
};

class Square : public Figure
{
public:
	Square(Line& length1)
	{
		P = 4 * length1.Get_Length();
		S = pow(length1.Get_Length(), 2);
		diagonal = length1.Get_Length() * sqrt(2);
	}

	void Print()
	{
		cout << "Perimeter = " << Get_P() << " cm\n";
		cout << "Area = " << Get_S() << " cm squared\n";
		cout << "Diagonal = " << Get_diagonal() << " cm\n\n";
	}

	~Square() {}
};

class Rectangle : public Figure
{
public:
	Rectangle(Line& length1, Line& length2)
	{
		P = 2 * (length1.Get_Length() + length2.Get_Length());
		S = length1.Get_Length() * length2.Get_Length();
		diagonal = sqrt(pow(length1.Get_Length(), 2) + pow(length2.Get_Length(), 2));
	}

	void Print()
	{
		cout << "Perimeter = " << Get_P() << " cm\n";
		cout << "Area = " << Get_S() << " cm squared\n";
		cout << "Diagonal = " << Get_diagonal() << " cm\n\n";
	}

	~Rectangle() {}
};

class Triangle : public Figure
{
public:
	Triangle(Line& length1, Line& length2, Line& length3)
	{
		P = length1.Get_Length() + length2.Get_Length() + length3.Get_Length();
		if (length1.Get_Length() == length2.Get_Length() == length3.Get_Length())
		{
			cout << "This is an equilateral triangle\n";
			S = (pow(length1.Get_Length(), 2) * sqrt(3)) / 4;
		}
		else if (length1.Get_Length() == length2.Get_Length())
		{
			cout << "This is an isosceles triangle\n";
			h = sqrt(pow(length1.Get_Length(), 2) - (pow(length3.Get_Length(), 2)) / 4);
			S = length3.Get_Length() / 2 * h;
		}

		else if (length1.Get_Length() == length3.Get_Length())
		{
			cout << "This is an isosceles triangle\n";
			h = sqrt(pow(length1.Get_Length(), 2) - (pow(length2.Get_Length(), 2)) / 4);
			S = length2.Get_Length() / 2 * h;
		}

		else if (length2.Get_Length() == length3.Get_Length())
		{
			cout << "This is an isosceles triangle\n";
			h = sqrt(pow(length2.Get_Length(), 2) - (pow(length1.Get_Length(), 2)) / 4);
			S = length1.Get_Length() / 2 * h;
		}

		else
		{
			cout << "It's a versatile triangle\n";
			p = P / 2;
			S = sqrt(p * (p - length1.Get_Length()) * (p - length2.Get_Length()) * (p - length3.Get_Length()));
		}
	}

	void Print() override
	{
		cout << "Perimeter = " << Get_P() << " cm\n";
		cout << "Area = " << Get_S() << " cm squared\n";
	}

	~Triangle() {}
};

int main()
{
	Point A(0, 0);
	Point B(0, 5);
	Point C(8, 5);
	Point D(8, 0);
	Point N(5, 5);
	Point H(5, 0);
	cout << "Point\n"; A.Print(); B.Print(); C.Print(); D.Print(); cout << endl;

	Line AB(A, B);
	Line BC(B, C);
	Line CD(C, D);
	Line DA(D, A);
	Line AC(A, C);
	Line NH(N, H);
	cout << "Line\n"; AB.Print(); BC.Print(); AC.Print(); cout << endl;

	cout << "Circle\n"; Circle E(15, 12, 4); E.Print();

	cout << "Square\n"; Square ABNH(NH); ABNH.Print();

	cout << "Rectangle\n"; Rectangle ABCD(AB, BC);	ABCD.Print();

	cout << "Triangle\n"; Triangle ABC(AB, BC, AC); ABC.Print();

	system("pause");
	return 0;
}
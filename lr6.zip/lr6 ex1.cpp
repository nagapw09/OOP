﻿// lr6 ex1.cpp
/* Построить класс с указанными в индивидуальном задании полями и методами:
- конструктор;
- функция, которая определяет «качество» объекта - Q по заданной формуле (столб 2);
- вывод информации об объекте.

10. Программист:
 - фамилия;
 - число программ, написанных программистом;
 - число языков программирования, которыми он пишет программы.
 Q = (число программ)*(число языков) */

#include <iostream>
#include <string>
using namespace std;

class Programmer
{
protected:
    string surname; int number_programs; int number_languages; double Q;
public:
    Programmer() { string surname = ""; int number_programs = 0; int number_languages = 0; }

    Programmer(string _surname, int _number_programs, int _number_languages)
    {
        surname = _surname;
        number_programs = _number_programs;
        number_languages = _number_languages;
    }

    string Get_surname() { return surname; }

    int Get_number_programs() { return number_programs; }

    int Get_number_languages() { return number_languages; }

    double Get_Q() { return Q; }

    void qualityQ()
    {
        Q = number_programs * number_languages;
    }

    void Print()
    {
        cout << "Фамилия программиста - " << Get_surname() << "\nЧисло программ, написанных программистом = " << Get_number_programs() << "\nЧисло языков программирования, которыми он пишет программы = " << Get_number_languages() << "\nКачество = " << Get_Q() << "\n\n";
    }

    ~Programmer() {}
};

int main()
{
    setlocale(LC_ALL, "Ru");

    Programmer first("Иванов", 45, 3);
    first.qualityQ();
    first.Print();

    Programmer second("Сидоров", 24, 2);
    second.qualityQ();
    second.Print();

    system("pause");
    return 0;
}